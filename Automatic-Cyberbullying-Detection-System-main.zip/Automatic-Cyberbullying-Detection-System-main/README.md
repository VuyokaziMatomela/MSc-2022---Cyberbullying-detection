# Automatic-Cyberbullying-Detection-System
This is a system that is capable of detecting instances of bullying on social media platforms.
