# Cyberbullying-detection
Cyberbullying detection on Hindi-English code-mixed YouTube comments
* Built a multi-class machine learning classification algorithm based on Python that is trained to identify cyberbullying messages in Hindi-English code-mixed language on YouTube comments section.	
* The findings are summarized  and visualised on a dashboard to show the trends.	
